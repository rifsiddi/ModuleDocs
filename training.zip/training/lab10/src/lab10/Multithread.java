package lab10;

import java.time.LocalTime;
import java.util.Scanner;

public class Multithread implements Runnable{
	public void run()
	  {
		try
        {
			int n = 0;
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter the number of threads:");
			String s= sc.nextLine();
			n=Integer.parseInt(s);
			if(n>0) {
			for(int i=1;i<=n;i++){
			LocalTime time=LocalTime.now();
			System.out.println(time);
			Thread.sleep (10000);
			}
			}
			else {
				System.out.println("Enter positive integer number");
			
			}
        }
        catch(NumberFormatException e) {
        	System.out.println("Enter a valid natural number");
        }
        catch (InterruptedException interruptedException)
        {
        	System.out.println( "Thread is interrupted when it is sleeping" +interruptedException);
     
        }
	  }
	 public static void main(String args[])
     {
        Multithread   firstThread = new Multithread();
        Thread thread1 = new Thread(firstThread);
        thread1.start();
  
     }
}
