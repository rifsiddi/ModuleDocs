package lab8;

import java.io.File;
import java.util.Scanner;

public class Ex4 {
	public static String check(boolean n)
	{
		String d="";
		if(n == true)
		{
			d="YES";
			return d;
		}
		else
		{
			d="NO";
			return d;
		}
	}
	private static String getFileExtension(File file)
	{
		String fileName = file.getName();
		return fileName.substring(fileName.lastIndexOf(".")+1);
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter File Name:");
		String str=sc.next();
		File f= new File(str);
		System.out.println("Exist:"+check(f.exists()));
		System.out.println("Readable:"+check(f.canRead()));
		System.out.println("Writable:"+check(f.canWrite()));
		System.out.println("Size:"+f.length());
		System.out.println("File Type:"+getFileExtension(f));
	}
	

}
