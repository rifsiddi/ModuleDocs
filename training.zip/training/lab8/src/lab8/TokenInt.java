package lab8;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
public class TokenInt {
	public static void main(String[] args) throws Exception {
		int sum=0;
		try {
			Scanner sc= new Scanner (System.in);
			System.out.println("Enter integer value with a space:");
			String num= sc.nextLine();
			StringTokenizer st= new StringTokenizer(num," ");
			while(st.hasMoreTokens())
			{
				String str=st.nextToken();
				int n=Integer.parseInt(str);
				System.out.println(n);
				sum=sum+n;
			}
			System.out.println("sum of all integers "+sum);
			sc.close();
		}
		catch (Exception e) {
			System.out.println("Invali Input");
		}
	}
}
