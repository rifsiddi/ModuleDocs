package lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ex3 {
	public static void main(String args[]) throws IOException {
		int lc=0, wc=0,cc=0;
		BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\rifsiddi\\Desktop\\file.txt"));
		String line = reader.readLine();
				while (line != null){
					cc+=line.length();
					String[] wordlist = line.split("\\s+");
					wc+=wordlist.length;
					
					String[] sentenceList = line.split("[?!.]");
					lc+=sentenceList.length;
				}
				System.out.println("Count of lines in file:"+lc);
				System.out.println("Count of words in file:"+wc);
				System.out.println("Count of letters in file:"+cc);
	}
}
