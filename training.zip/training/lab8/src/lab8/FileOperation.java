package lab8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileOperation {

	public static void main(String args[]) throws IOException {
		BufferedReader reader;
		int x=1;
		try {
			reader = new BufferedReader(new FileReader("C:\\Users\\rifsiddi\\Desktop\\file.txt"));
			String line = reader.readLine();
			while (line != null) {
				System.out.println(x+" ");
				System.out.println(line);
				line = reader.readLine();
				x++;
			}
			reader.close();
		}
		
		catch (FileNotFoundException e) {
			System.out.println("File not found...");
			e.printStackTrace();
		}
	}
}
