package lab8;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
public class Ex6 {
	int d,m,y;
	Scanner sc = new Scanner(System.in);
	public void getDate() {
		System.out.println("Enter date(dd):");
		d=sc.nextInt();
		System.out.println("Enter month(mm):");
		m=sc.nextInt();
		System.out.println("Enter year(yyyy):");
		y=sc.nextInt();
	}
	public static void main(String[] args) {
		Ex6 l =new Ex6();
		l.getDate();
		LocalDate id = LocalDate.of(l.y,l.m,l.d);
		LocalDate d1= LocalDate.now();
		System.out.println(id);
		Period gap = Period.between(id, d1);
		System.out.println("Difference between "+id+" & "+d1+" is:\nIn days:"+gap.getDays()+"\nIn months:"+gap.getMonths()+"\nIn Years:"+gap.getYears());
		
	}

}
