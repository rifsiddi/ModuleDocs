package lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterJobseeker {

	public static void main(String[] args) {
		System.out.println("Enter your username of atleast 8 characters");
		Scanner sc=new Scanner(System.in);
		String username=sc.nextLine();
		username=username.concat("_job");
		RegisterJobseeker rj= new RegisterJobseeker();
		boolean value=rj.validateUser(username);
		if(value==true)
		{
			System.out.println("Validation passed :" +username);
		}
		else
		{
			System.out.println("Validation failed");
		}
		sc.close();
	
	}
	boolean validateUser(String username)
	{
	Pattern pattern = Pattern.compile("[a-zA-z]{8,20}(_job)$");
	Matcher matcher= pattern.matcher(username);
	if(matcher.matches()) {
		return true;
	}
	else
	{
		return false;
	}
	}
}
