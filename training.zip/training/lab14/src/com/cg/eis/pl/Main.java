package com.cg.eis.pl;

import java.util.List;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class Main {
	public static Employee acceptEmployeeDetails() {
		Employee emp= new Employee();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		String id= sc.next();
		emp.setId(id);
		System.out.println("Enter Name:");
		String name= sc.next();
		emp.setName(name);
		System.out.println("Enter Salary:");
		double sal= sc.nextDouble();
		emp.setSalary(sal);
		System.out.println("Enter Designation:");
		String designation="";
		designation+= sc.nextLine();
		emp.setDesignation(designation);
		String scheme=emp.check(sal,designation);
		emp.setInsuranceScheme(scheme);
		return emp;
	}
	public static void displayEmployees(List<Employee> emplist) {
		for(Employee e: emplist) {
			System.out.println(e.getId()+" ");
			System.out.println(e.getName()+" ");
			System.out.println(e.getSalary()+" ");
			System.out.println(e.getDesignation()+" ");
			System.out.println(e.getInsuranceScheme()+"\n");
		}
		public static void displayEmployeeScheme() {
			System.out.println("Employee List:");
			System.out.println(displayEmp);
		}
	public static void main(String args[]) {
		Service service= new Service();
		Main m= new Main();
		Scanner sc= new Scanner(System.in);
		do {
			System.out.println("1.Add Employee");
			System.out.println("2.Display Employee List");
			System.out.println("3.Find the insurance scheme for an employee");
			System.out.println("4.Exit");
			System.out.println("Enter Option:");
			Scanner in=new Scanner(System.in);
			int option= sc.nextInt();
			switch(option) {
			case 1: 
				Employee e= m.acceptEmployeeDetails();
				e=service.addEmployee(e);
				System.out.println("1 Employee added...");
				break;
			case 2:
				List<Employee> list=service.getEmployees();
				displayEmployees(list);
				break;
			case 3:
				System.out.println("Enter Employee ID:");
				int employeeID= sc.nextInt();
				String displayEmp= service.getEmployee(employeeID);
				displayEmployeeScheme(displayEmp);
				break;
			case 4:
				System.out.println("Exit");
				in.close();
				System.exit(0);
				break;
			}
		}
		while(true);
}
}