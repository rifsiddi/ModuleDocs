package com.cg.eis.service;

import java.util.List;
import com.cg.eis.exception.EmployeeException;
import java.util.List;
import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAO;
import com.cg.eis.dao.EmployeeDAOImpl;

public class Service implements EmployeeService{
	EmployeeDAO dao;
	public EmployeeService dao=new EmployeeService(); 
	
	public Employee addEmployee(Employee emp) {
		return dao.addEmployee(emp);
	}
	
	public List<Employee> getEmployees() {
		return dao.getEmployees();
	}
	
	public String getEmployee(int empID) {
		return dao.getEmployee(empID);
	}

	@Override
	public Employee getEmployee(String empid) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}
}



/*		EmployeeDAO dao;
		DataValidator validator;
		public Service() {
			dao=(EmployeeDAO) new EmployeeDAOImpl();
			validator=new DataValidator();
		}
		
		public Employee addEmployee(Employee emp) throws EmployeeException{
			boolean res1=validator.validateId(emp.getId());
			boolean res2=validator.validateName(emp.getName());
			boolean res3=validator.validateSalary(emp.getSalary());
			boolean res4=validator.validateDesignation(emp.getDesignation());
			boolean res5=validator.validateInsuranceScheme.(emp.getInsuranceScheme());
			if(res1==false)
			{
				try 
				{
					throw new EmployeeException("Id is not valid");
				}
				catch(EmployeeException e)
				{
					throw e;
				}
			}
			else if(res2==false)
			{
				try 
				{
					throw new EmployeeException("Name is not valid");
				}
				catch(EmployeeException e)
				{
					throw e;
				}
			}
				else if(res3=false)
				{
					try {
						throw new EmployeeException("Salary is not valid");
					}catch(EmployeeException e)
					{
						throw e;
					}
				}
				else if(res4==false)
				{
					try {
						throw new EmployeeException("Designation is not valid");
					}catch(EmployeeException e)
					{
						throw e;
					}
				}
				else if(res5==false)
				{
					try {
						throw new EmployeeException("Insurance Scheme is not valid");
					}catch(EmployeeException e)
					{
						throw e;
					}
				}
				return dao.addEmployee(emp);
			}


		@Override
		public List<Employee> getEmployees() throws EmployeeException {
			// TODO Auto-generated method stub
			return dao.getEmployees();
		}
		public Employee getEmployee(String empid) throws EmployeeException{
			return dao.getEmployee(empid);
		}
*/

