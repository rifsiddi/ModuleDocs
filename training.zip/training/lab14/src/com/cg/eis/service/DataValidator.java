package com.cg.eis.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {
	public Object validateInsuranceScheme;
	public boolean validateName(String name) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{4,}");
		Matcher mat=pattern.matcher(name);
		return mat.matches();
	}
	public boolean validateId(String id) {
		Pattern pattern= Pattern.compile("[0-9]");
		Matcher mat=pattern.matcher(id);
		return mat.matches()   ;
		
	}
	public boolean validateDesignation(String des) {
		if(des.equals("System Associate")|| des.equals("Programmer") ||
		   des.equals("Manager") || des.equals("Clerk"))
			return true;
			return false;
	}
	public boolean validateSalary(String sal) {
		Pattern pattern= Pattern.compile("[0-9]");
		Matcher mat=pattern.matcher(sal);
		return mat.matches()   ;
	}
	public boolean validateInsuranceScheme(String sch) {
		if(sch.equals("Scheme C")|| sch.equals("Scheme B") ||
		   sch.equals("Scheme A") || sch.equals("No Scheme"))
			return true;
			return false;
}
}
