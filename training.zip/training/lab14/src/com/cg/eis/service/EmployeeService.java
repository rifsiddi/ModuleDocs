package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {
	public List<Employee> getEmployees() throws EmployeeException;
	public Employee getEmployee(String empid) throws EmployeeException;
	public String getEmployee(int empID);
	public Employee addEmployee(Employee emp);
}
