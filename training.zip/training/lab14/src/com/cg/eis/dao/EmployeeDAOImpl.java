
package com.cg.eis.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;



public class EmployeeDAOImpl {
private static Map<String,Employee> employees=new HashMap<>();
	
	public Employee addEmployee(Employee emp) {
		employees.put(emp.getId(), emp);
		return emp;
	}
	public List<Employee> getEmployees() {
		Collection<Employee> list=employees.values();
		List<Employee> empList=new ArrayList<>(list);
		return empList;
	}
	public Employee getEmployee(String empid) throws EmployeeException {
		Employee emp=employees.get(empid);
		
		if(emp==null)
			throw new EmployeeException();
		else return emp;
	}
}
