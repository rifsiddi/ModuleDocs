package com.cg.eis.dao;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
public interface EmployeeDAO {
	public Employee addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getEmployees() throws EmployeeException;
	public Employee getEmployee(int empID) throws EmployeeException;
}
