package lab13;

import java.util.Scanner;
import java.util.function.Consumer;

public class Factorial {
	private void factorial(int n)
	{
		int i, fact=1;
		for(i=1;i<=n;i++)
		{
		fact=fact*i;
		}
		System.out.println("Factorial of "+n+" is "+fact);
	}
	public static void main(String[] args) {
		Factorial f= new Factorial();
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number:");
	    int s=sc.nextInt();
	    Consumer<Integer> con=f::factorial;
	    con.accept(s);
	    sc.close();
	}
}
