package lab13;

import java.util.Scanner;

public class PowerOf {
	public static void main(String[] args) {
	        	  Scanner sc=new Scanner(System.in);
	        	  System.out.println("Enter Numbers:");
	        	  PowerDemo pd=(double x, double y)->Math.pow(x,y);
	        	  double x=sc.nextDouble();
	        	  double y=sc.nextDouble();
	        	  double res=pd.CalculatePower(x,y);
	              System.out.println("Power is "+res);
	              sc.close();
	         
	 }

}
