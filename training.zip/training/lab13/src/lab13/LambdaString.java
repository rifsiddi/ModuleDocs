package lab13;

import java.util.Scanner;
import java.util.function.Consumer;

public class LambdaString {
	public static void main(String[] args) {
  	  Scanner sc=new Scanner(System.in);
  	  System.out.println("Enter String:");
  	  String s=sc.nextLine();
  	  StringDemo sd=(String v)->{
  		  String StrSpace="";
  		  for(int i=0;i<s.length();i++) {
  			  StrSpace+=s.charAt(i);
  			  StrSpace+=" ";
  		  }
  		  return (StrSpace);
  	  };
  	  String StrSpace=sd.stringToChar(s);
  	  //Consumer<String> con=(string)->System.out.println("String with space: "+string);
  	  //con.accept(StrSpace);
  	  System.out.println("String with space: "+StrSpace);
  	  sc.close();
  	   
  	  }
}
