package lab13;

import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Ex4 {
	
	private int empid;
	private String empname;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	
	public static void main(String[] args) {
		Ex4 e4= new Ex4();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		int empid=sc.nextInt();
		System.out.println("Enter Employee Name:");
		String empname=sc.next();
		
	    Consumer<String> con1=e4::setEmpname;
	    Consumer<Integer> con2=e4::setEmpid;
	    
	    con1.accept(empname);
	    con2.accept(empid);
	    
	    Supplier<String> sup1=e4::getEmpname;
	    Supplier<Integer> sup2=e4::getEmpid;
	    
	    System.out.println(sup1.get());
	    System.out.println(sup2.get());
	    
	    }

}
