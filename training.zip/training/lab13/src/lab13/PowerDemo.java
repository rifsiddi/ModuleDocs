package lab13;
import java.lang.FunctionalInterface;
public interface PowerDemo {
	    double CalculatePower(double x, double y);
	
}
