package lab13;

public interface Ex3Demo {
	boolean toName(String x, String y);
}
