package lab13;

public interface StringDemo {
	String stringToChar(String v);
}
