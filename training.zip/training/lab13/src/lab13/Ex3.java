package lab13;

import java.util.Scanner;

public class Ex3 {
	public static void main(String[] args) {
  	  Scanner sc=new Scanner(System.in);
  	  System.out.println("Enter Username:");
  	  String u=sc.nextLine();
	  System.out.println("Enter Password:");
	  String p=sc.nextLine();
  	  Ex3Demo e3=(String x, String y)->{
  		  if(u.equals("Admin") && p.equals("admin123")) {
  			  return true;
  		  }
  		  else
  		  {
  			  return false;
  		  }
  	  };
  	    boolean res=e3.toName(u, p);
        System.out.println(res);
        sc.close();
	}
}
