package com.capg.ems.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JUnit5 {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
