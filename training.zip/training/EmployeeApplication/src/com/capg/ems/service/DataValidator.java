package com.capg.ems.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {
	public boolean validateName(String name) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{4,}");
		Matcher mat=pattern.matcher(name);
		return mat.matches();
	}
	public boolean validateMobileNo(String mobile) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher mat=pattern.matcher(mobile);
		return mat.matches()   ;
		
	}
	public boolean validateLocation(String loc) {
		if(loc.equals("Mumbai")|| loc.equals("Chennai") ||
		   loc.equals("Noida") || loc.equals("Pune"))
			return true;
			return false;
	}
	public boolean validateEmpId(String id) {
		Pattern pattern= Pattern.compile("[0-9]{6}");
		Matcher mat=pattern.matcher(id);
		return mat.matches()   ;
	}


}
