package com.capg.ems.service;
import java.util.List;

import com.capg.ems.dto.Employee;
import com.capg.ems.exception.EmployeeException;

public interface EmployeeService  {

	public Employee addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getEmployees() throws EmployeeException; 
	public Employee deleteEmployee(String empid) throws EmployeeException;
	public Employee getEmployee(String empid) throws EmployeeException;
	public Employee updateEmployee(Employee emp) throws EmployeeException;
}
