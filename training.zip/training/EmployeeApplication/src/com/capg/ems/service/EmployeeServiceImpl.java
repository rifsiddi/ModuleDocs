package com.capg.ems.service;
import com.capg.ems.dao.EmployeeDAO;
import com.capg.ems.dao.EmployeeDAOImpl;
import com.capg.ems.exception.EmployeeException;
import java.util.List;

import com.capg.ems.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDAO dao;
	DataValidator validator;
	public EmployeeServiceImpl() {
		dao=new EmployeeDAOImpl();
		validator=new DataValidator();
	}
	
	public Employee addEmployee(Employee emp) throws EmployeeException{
		boolean res1=validator.validateEmpId(emp.getEmpId());
		boolean res2=validator.validateName(emp.getName());
		boolean res3=validator.validateMobileNo(emp.getMobileNo());
		boolean res4=validator.validateLocation(emp.getLocation());
		if(res1==false)
		{
			try 
			{
				throw new EmployeeException("EmpId is not valid");
			}
			catch(EmployeeException e)
			{
				throw e;
			}
		}
		else if(res2==false)
		{
			try 
			{
				throw new EmployeeException("Name is not valid");
			}
			catch(EmployeeException e)
			{
				throw e;
			}
		}
			else if(res3=false)
			{
				try {
					throw new EmployeeException("Mobile Number is not valid");
				}catch(EmployeeException e)
				{
					throw e;
				}
			}
			else if(res4==false)
			{
				try {
					throw new EmployeeException("Location is not valid");
				}catch(EmployeeException e)
				{
					throw e;
				}
			}
			return dao.addEmployee(emp);
		}


	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployees();
	}
	public Employee deleteEmployee(String empid) throws EmployeeException{
		return dao.deleteEmployee(empid);
	}
	public Employee getEmployee(String empid) throws EmployeeException{
		return dao.getEmployee(empid);
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		return dao.updateEmployee(emp);
	}
	
}
