package com.capg.ems.presentation;

import java.util.List;
import java.util.Scanner;
import com.capg.ems.dto.Employee;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.service.EmployeeService;
import com.capg.ems.service.EmployeeServiceImpl;
public class MainClass {
	public static Employee acceptEmployeeDetails() {
		Employee emp= new Employee();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		String id= sc.next();
		emp.setEmpId(id);
		System.out.println("Enter Name:");
		String name= sc.next();
		emp.setName(name);
		System.out.println("Enter Salary");
		double sal= sc.nextDouble();
		emp.setSalary(sal);
		System.out.println("Enter Mobile no");
		String mob= sc.next();
		emp.setMobileNo(mob);
		System.out.println("Enter Dept code");
		int dno= sc.nextInt();
		emp.setDeptcode(dno);
		System.out.println("Enter Location");
		String loc= sc.next();
		emp.setLocation(loc);
		return emp;
	}
	
	public static void displayEmployees(List<Employee> emplist) {
		for(Employee e: emplist) {
			System.out.println(e.getEmpId()+" ");
			System.out.println(e.getName()+" ");
			System.out.println(e.getMobileNo()+" ");
			System.out.println(e.getLocation()+" ");
			System.out.println(e.getDeptcode()+" ");
			System.out.println(e.getSalary()+" ");
		}
	}
	public static void main(String args[]) {
		EmployeeService service= new EmployeeServiceImpl();
		do {
			
		
		System.out.println("1.Add Employee");
		System.out.println("2.Display Employee List");
		System.out.println("3.Delete Employee");
		System.out.println("4.Update Employee");
		System.out.println("5.Display Employee");
		System.out.println("Enter Option : ");
		Scanner sc=new Scanner(System.in);
		int option= sc.nextInt();
		switch(option) {
		case 1: 
			Employee emp= acceptEmployeeDetails();
			try {
				emp=service.addEmployee(emp);
				System.out.println("employee added ....");
			}
			catch(EmployeeException e) {
				System.out.println(e.getMessage());
			}
				break;
		case 2:	
			try
			{
			List<Employee> list= service.getEmployees();
			displayEmployees(list);
		}
			catch(EmployeeException e) {
				System.out.println(e.getMessage());
			}
				break;
		
		case 3:
			System.out.println("Enter Employee id ");
			String id= sc.next();
			try
			{
				emp= service.deleteEmployee(id);
				System.out.println("Employee Deleted...");
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 4:
			Employee emp1=acceptEmployeeDetails();
			try {
				emp=service.updateEmployee(emp1);
				System.out.println("employee updated successfully .....");
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
			
		case 5:
			System.out.println("Enter Employee id ");
			String id1= sc.next();
			try
			{
				emp= service.getEmployee(id1);
				System.out.println("Employee Details: "+emp);
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
		case 6:
			System.out.println("Exit");
			sc.close();
			System.exit(0);
		
		default:
			System.out.println();
			break;
		}
		}
		while(true);
	}
}

