package com.capg.ems.exception;

public class EmployeeException extends Exception{
	public EmployeeException() {
	}
	public EmployeeException(String str) {
		super(str);
	}
}
