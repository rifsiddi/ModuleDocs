//package com.cg.ems.pl;
//
//public class MainClass {
//
//}

package com.cg.ems.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.ems.dao.CustomerDAOimpl;
import com.cg.ems.dao.CustomerDao;
import com.cg.ems.dto.Customer;
import com.cg.ems.exception.CustomerException;
import com.cg.ems.service.CustomerService;
import com.cg.ems.service.CustomerServiceimpl;
//import com.cg.ems.service.CutomerServiceimpl;
//import com.cg.ems.service.CutosmerService;

public class MainClass {
	public static Customer acceptcustomerdetails()
	{
		Customer cum=new Customer();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Account No:");
		//String accno=sc.next();
		cum.setAccono(Integer.toString((int)Math.random()*100000));
		System.out.println("Enter Name:");
		String name=sc.next();
		cum.setName(name);
		System.out.println("Enter Your Age:");
		int age=sc.nextInt();
		cum.setAge(age);
		
		
		System.out.println("Enter your Occupation:");
		String occ=sc.next();
		cum.setOccupation(occ);
		System.out.println("Enter Mobile No:");
		String mob=sc.next();
		cum.setMobilno(mob);
		System.out.println("Enter Current address:");
		String add=sc.next();
		cum.setAddress(add);
		cum.getAccono();
		return cum;
	}
public static void displayCustomer(List<Customer> cumlist) {
		
		for(Customer c: cumlist) {
			System.out.println(c.getAccono()+" ");
			System.out.println(c.getName()+ " ");
			System.out.println(c.getOccupation()+" ");
			System.out.println(c.getAddress()+" ");
			System.out.println(c.getMobilno()+" ");
			System.out.println(c.getAge()+" ");
		}
	

}
public static void main(String[] args) {
	CustomerService service=new CustomerServiceimpl();
	CustomerDao dao=new CustomerDAOimpl();
	
	do {
		
	System.out.println("\n\n");
	System.out.println("1.Create account");
	System.out.println("2.Show balance");
	System.out.println("3.Deposit");
	System.out.println("4.Update cutomer details");
	System.out.println("5.Display Customer");
	System.out.println("6.Delete Customer");
	System.out.println("7.Fund Tarnsfer");
	System.out.println("8.Print Trannsaction");
	System.out.println("9.Exit");
	System.out.println("Enter Option");
	Scanner sc= new Scanner(System.in);
	int option=sc.nextInt();
	switch(option) {
	case 1:
		Customer cum=acceptcustomerdetails();
		try {
			cum=service.addCustomer(cum);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("account Created.....");
		break;
	case 5:
		System.out.println("Enter emp id");
		
		String id1=sc.next();
		try {
			cum=dao.getCustomer(id1);
			System.out.println("Employee Details: "+cum.toString());
		}catch(CustomerException e)
		{
			System.out.println(e.getMessage());
		}
		break;
	
		

}
	}while(true);
	
}
}
