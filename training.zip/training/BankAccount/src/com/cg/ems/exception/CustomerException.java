//package com.cg.ems.exception;
//
//public class CustomerException {
//
//}

package com.cg.ems.exception;

public class CustomerException  extends Exception{
	public void CutomerException()
	{
		
	}
	public CustomerException(String str)
	{
		super(str);
	}

}
