//package com.cg.ems.dto;
//
//public class Customer {
//
//}
package com.cg.ems.dto;

public class Customer {
	private String accono;
	private String name;
	private  String occupation;
	private String address;
	private String mobilno;
	private int age;
	public String getAccono() {
		return accono;
	}
	public void setAccono(String accono) {
		this.accono = accono;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobilno() {
		return mobilno;
	}
	public void setMobilno(String mobilno) {
		this.mobilno = mobilno;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String toString()
	{
		return "Accout No:"+"accno"+"Account holder Name"+name+"Age:"+age+"Address"+address+"Mobile no:"+mobilno;
	}

}
