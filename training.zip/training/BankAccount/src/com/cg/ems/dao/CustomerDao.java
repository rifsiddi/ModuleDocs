//package com.cg.ems.dao;
//
//public interface CustomerDao {
//
//}
package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.dto.Customer;
import com.cg.ems.exception.CustomerException;



public interface CustomerDao {
	public Customer addCustomer(Customer cum) throws CustomerException;
	
//	Customer deletecustomer(String empid) throws CustomerException;
	//public Customer getCustomer(String accon)throws CustomerException;
//	List<Customer> getCustomer() throws CustomerException;

	Customer getCustomer(String accono) throws CustomerException;
	

}
