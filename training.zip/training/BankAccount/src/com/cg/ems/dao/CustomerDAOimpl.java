//package com.cg.ems.dao;
//
//public class CustomerDAOimpl {
//
//}

package com.cg.ems.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import com.capg.ems.dto.Employee;
//import com.capg.ems.dto.Employee;
import com.cg.ems.dto.Customer;
import com.cg.ems.exception.CustomerException;



public class CustomerDAOimpl implements CustomerDao {
	//CustomerDao dao;
	private static Map<String,Customer> customers=new HashMap<>();
	
	public Customer addCustomer(Customer cum) {
		customers.put(cum.getAccono(),cum);
		return cum;
	}
//
//	@Override
//	public List<Customer> getCustomer() throws CustomerException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Customer deletecustomer(String acono) throws CustomerException {
//		// TODO Auto-generated method stub
//		return null;
	//}

	@Override
	public Customer getCustomer(String accon) throws CustomerException {
		// TODO Auto-generated method stub
		System.out.println("dao");
		Customer cum=customers.get(accon);
				
		return cum;
	}

	
	//@Override
	/*public List<Customer> getCustomers() {
		Collection<Customer> list=customers.values();
		List<Customer> cumlist=new ArrayList<>(list);
		return cumlist;
	}
	@Override
	/*public Customer deleteCustomer(String getAccono)throws CustomerException
	{
		Customer cum=customers.remove(getAccono);
		if(cum==null) {
			throw new CustomerException("Employee not found");}
		
		else return cum;
	}
	public Customer getEmployee(String empid)throws CustomerException
	{
		Customer cum=customers.get(empid);
		if(cum==null) {
			throw new CustomerException("Employee not found");}
		
		else return cum;
	}
*/

}
