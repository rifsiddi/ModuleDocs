//package com.cg.ems.service;
//
//public class Datavalidator {
//
//}

package com.cg.ems.service;

public class Datavalidator {

	public boolean validateAccono(String accono) {
		// TODO Auto-generated method stub
		return false;
	}

}
