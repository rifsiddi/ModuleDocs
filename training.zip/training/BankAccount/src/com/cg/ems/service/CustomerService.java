//package com.cg.ems.service;
//
//public interface CustomerService {
//
//}
package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dto.Customer;
import com.cg.ems.exception.CustomerException;

public interface CustomerService {
	public Customer addCustomer(Customer cum) throws CustomerException;
//	public List<Customer> getCustomer() throws CustomerException;
//	Customer deletecustomer(String accono) throws CustomerException;
	//public Customer getEmployee(String accono)throws CustomerException;
	Customer getCustomer(String accono) throws CustomerException;
	//Customer getCustomer(Customer accono) throws CustomerException;

}
