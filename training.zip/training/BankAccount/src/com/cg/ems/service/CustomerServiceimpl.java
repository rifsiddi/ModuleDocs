//package com.cg.ems.service;
//
//public class CustomerServiceimpl {
//
//}

package com.cg.ems.service;


import java.util.List;

import com.cg.ems.dao.CustomerDAOimpl;
import com.cg.ems.dao.CustomerDao;
//import com.cg.ems.dao.CustomerDAO;
import com.cg.ems.dto.Customer;
import com.cg.ems.exception.CustomerException;

public  class CustomerServiceimpl implements CustomerService {
	
	CustomerDao dao ;
	Datavalidator validator;
	public CustomerServiceimpl() {
		dao=new CustomerDAOimpl();
		validator = new Datavalidator();
	}

	
	
//	@Override
//	public List<Customer> getCustomer() throws CustomerException {
//		// TODO Auto-generated method stub
//		return null;
//	}



//	@Override
//	public Customer deletecustomer(String accono) throws CustomerException {
//		// TODO Auto-generated method stub
//		return null;
//	}



	@Override
	public Customer getCustomer(String accono) throws CustomerException {
		// TODO Auto-generated method stub
		System.out.println("get");
		 return dao.getCustomer(accono);
	}

//	@Override
//	public List<Customer> getCustomer() throws CustomerException {
//		// TODO Auto-generated method stub
//		return null;
//	}



	@Override
	public Customer addCustomer(Customer cum) throws CustomerException {
		dao = new CustomerDAOimpl();
		return dao.addCustomer(cum);
	}



	
}
