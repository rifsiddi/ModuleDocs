import java.util.Scanner;

public class calculateDifference {
	int calculateDifference(int n)
	{
		int sum=0, r=0, sqr, diff;
		for(int i=1;i<=n;i++)
		{
			r=r+i;
			sum=sum + i*i;
		}
		sqr=r*r;
		diff= sum-sqr;
		return diff;
		
	}
	public static void main(String[] args) {
		calculateDifference obj = new calculateDifference();
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n::");
		String s= sc.nextLine();
	    try {
	    n=Integer.parseInt(s);
	    if(n>=0) {
	    	System.out.println("Difference is " +obj.calculateDifference(n));
	
	    }
	    else 
	    {
	    	System.out.println("Enter a positive integer number");
	    }
	    
	}
	   
		catch(NumberFormatException e) {
		
			System.out.println("Enter a valid natural number");
			
		}
	}
	
}
