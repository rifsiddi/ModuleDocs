package lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class HashMapSorting {
		public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		HashMap <Integer,String> map=new HashMap<>();
		System.out.println("Enter the no of elements of map");
		int n=sc.nextInt();
		System.out.println("Enter the string values in map");
		for(int i=1;i<=n;i++)
		{
		String str=sc.next();
		map.put(i,str);
		}
		List<String> res=getValues(map);
		System.out.println("sorted values of the map");
		res.forEach(System.out::println);
		sc.close();

		}
		public static List<String> getValues(HashMap<Integer,String> map)
		{
		List<String> result=new ArrayList<String> (map.values());
		Collections.sort(result);
		return result;
		}


}
