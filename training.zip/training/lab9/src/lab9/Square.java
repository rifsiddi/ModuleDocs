package lab9;
import java.util.HashMap;
import java.util.Scanner;

public class Square {
static Scanner sc=new Scanner(System.in);
public static void main(String[] args) {
System.out.println("Enter the no of elements");
int n=sc.nextInt();
int array[]=new int[n];
HashMap<Integer,Integer> h=getSquares(array);
System.out.println(h);
}

public static HashMap<Integer, Integer> getSquares(int[] array) {
HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
System.out.println("Enter elements into the list");
for(int i=0;i<array.length;i++)
{
int squ=0;
array[i]=sc.nextInt();
int k=array[i];
squ=k*k;
map.put(k,squ);
}
return map;
}
}
