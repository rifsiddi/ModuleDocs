package lab9;

import java.util.HashMap;
import java.util.Scanner;

public class CollectionCharacterCount {
		public static void main(String[] args) {
		System.out.println("Enter no of characters:");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		char[] array=new char[n];
		for(int i=0;i<n;i++)
		{
		System.out.println("Enter character " +(i+1));
		array[i]=sc.next().charAt(0);
		}
		HashMap<Character,Integer> h=getValues(array);
		System.out.println(h);
		sc.close();
		}
		static HashMap<Character,Integer> getValues(char[] c){
		HashMap<Character,Integer> map=new HashMap<Character,Integer>();
		int count=0;
		 
		for(int i=0;i<c.length;i++)
		{
		count=0;
		for(int j=i;j<c.length;j++)
		{
		if(c[i]==c[j]) {
		count++;
		}
		}
		if(!map.containsKey(c[i])) {
		 
		map.put(c[i], count);
		}
		}
		return map;

		}


}
