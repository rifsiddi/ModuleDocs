package com.cg.cpg.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.cpg.dao.BankDAO;
import com.cg.cpg.dao.BankDAOImpl;
import com.cg.cpg.dto.Bank;
import com.cg.cpg.exception.BankException;
import com.cg.cpg.service.BankService;
import com.cg.cpg.service.BankServiceImpl;

public class MainClass {
	public static Bank acceptcustomerdetails()
	{
		Bank bnk=new Bank();
		Scanner sc=new Scanner(System.in);
		System.out.println("Account No:");
		String accno=sc.next();
		bnk.setAccono(accno);
		System.out.println("Enter Name:");
		String name=sc.next();
		bnk.setName(name);
		System.out.println("Enter Your Age:");
		int age=sc.nextInt();
		bnk.setAge(age);
		System.out.println("Enter Mobile No:");
		String mob=sc.next();
		bnk.setMobilno(mob);
		System.out.println("Enter Current address:");
		String add=sc.next();
		bnk.setAddress(add);
		System.out.println("Enter Username:");
		String uname=sc.next();
		bnk.setUsername(uname);
		System.out.println("Enter Password:");
		String pass=sc.next();
		bnk.setPwd(pass);
		return bnk;
}
public static void displayCustomer(List<Bank> cumlist) {
		
		for(Bank c: cumlist) {
			System.out.println(c.getAccono()+" ");
			System.out.println(c.getName()+ " ");
			System.out.println(c.getAddress()+" ");
			System.out.println(c.getMobilno()+" ");
			System.out.println(c.getAge()+" ");
			System.out.println(c.getUsername()+" ");
			System.out.println(c.getPwd()+" ");
		}
	

}
public static void main(String[] args) {
	BankService service=new BankServiceImpl();
	BankDAO dao=new BankDAOImpl();
	
	do {
		
	System.out.println("\n\n");
	System.out.println("1.Create account");
	System.out.println("2.Show balance");
	System.out.println("3.Deposit");
	System.out.println("4.Withdraw");
	System.out.println("5.Fund Transfer");
	System.out.println("6.Print Transaction");
	System.out.println("7.Display Customer");
	System.out.println("8.Delete Customer");
	System.out.println("9.Update cutomer details");
	System.out.println("10.Display Customer List");
	System.out.println("11.Exit");
	System.out.println("Enter Option");
	Scanner sc= new Scanner(System.in);
	int option=sc.nextInt();
	switch(option) {
	case 1:
		Bank bnk=acceptcustomerdetails();
		try {
			bnk=service.addCustomer(bnk);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("account Created.....");
		break;
	case 7:
		System.out.println("Enter emp id");
		
		String id1=sc.next();
		try {
			bnk=dao.getCustomer(id1);
			System.out.println("Employee Details: "+bnk.toString());
		}catch(BankException e)
		{
			System.out.println(e.getMessage());
		}
		break;
	
		

}
	}while(true);
	
}
}

