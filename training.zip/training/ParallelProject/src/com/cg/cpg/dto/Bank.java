package com.cg.cpg.dto;

public class Bank {
	private String accono;
	private String name;
	private String address;
	private String mobilno;
	private String balance;
	private String username;
	private String pwd;
	private int age;
	public String getAccono() {
		return accono;
	}
	public void setAccono(String accono) {
		this.accono = accono;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobilno() {
		return mobilno;
	}
	public void setMobilno(String mobilno) {
		this.mobilno = mobilno;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Customer [accono=" + accono + ", name=" + name + ", address=" + address + ", mobilno=" + mobilno
				+ ", balance=" + balance + ", username=" + username + ", pwd=" + pwd + ", age=" + age + "]";
	}
}
