package com.cg.cpg.exception;

public class BankException  extends Exception{
	public void CutomerException()
	{
		
	}
	public BankException(String str)
	{
		super(str);
	}

}
