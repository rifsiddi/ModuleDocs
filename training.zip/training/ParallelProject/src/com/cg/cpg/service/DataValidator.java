package com.cg.cpg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {
	public boolean validateAccono(String accono) {
		Pattern pattern= Pattern.compile("[0-9]{12}");
		Matcher mat=pattern.matcher(accono);
		return mat.matches ();
	}

}
