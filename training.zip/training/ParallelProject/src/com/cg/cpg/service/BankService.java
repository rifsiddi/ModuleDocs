package com.cg.cpg.service;

import com.cg.cpg.dto.Bank;
import com.cg.cpg.exception.BankException;

public interface BankService {
	public Bank addCustomer(Bank bnk) throws BankException;
	Bank getCustomer(String accono) throws BankException;
}
