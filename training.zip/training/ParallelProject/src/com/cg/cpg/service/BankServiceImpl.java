package com.cg.cpg.service;

import com.cg.cpg.dao.BankDAO;
import com.cg.cpg.dao.BankDAOImpl;
import com.cg.cpg.dto.Bank;
import com.cg.cpg.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDAO dao ;
	DataValidator validator;
	public BankServiceImpl() {
		dao=new BankDAOImpl();
		validator = new DataValidator();
	}
	@Override
	public Bank getCustomer(String accono) throws BankException {
		// TODO Auto-generated method stub
		System.out.println("get");
		 return dao.getCustomer(accono);
	}
	@Override
	public Bank addCustomer(Bank bnk) throws BankException {
		dao = new BankDAOImpl();
		return dao.addCustomer(bnk);
	}
	
	public String ShowBalance(int accno) throws BankException {
		return null;
	}
	
	public Boolean deposit(int amount, int accno) throws BankException {
		return null;	
	}
	
	public Boolean withdraw(int amount, int accno) throws BankException {
		return null;
	}
}
