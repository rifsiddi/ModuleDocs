package com.cg.cpg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.cpg.dto.Bank;
import com.cg.cpg.exception.BankException;

public class BankDAOImpl implements BankDAO {
	
	private static Map<String,Bank> customers=new HashMap<>();

	public Bank addCustomer(Bank bnk) throws BankException {
		customers.put(bnk.getAccono(),bnk);
		return bnk;
	}

	
	public Bank getCustomer(String accono) throws BankException {
		System.out.println("dao");
		Bank bnk=customers.get(accono);
		return bnk;
	}

	public String ShowBalance(int accno) throws BankException {
		Bank acc=customers.get(accno);
		if(acc==null) 
			{
			throw new BankException("Account number not found");
			}
		else
		return acc.getBalance();
	}
	
	public Boolean deposit(int amount, int accno) throws BankException {
		Bank acc=customers.get(accno);
		int balance= Integer.parseInt(acc.getBalance());
		balance= balance+amount;
		acc.setBalance(String.valueOf(balance));
		return true;
	}
	
	public Bank withdraw(int amount,Bank bnk) throws BankException {
	//	Bank acc=customers.get(accno);
	//	int balance= Integer.parseInt(acc.getBalance());
		if(bnk.getBalance() amount)
		{
			bnk.getBalance()=bnk.getBalance()-amount;
			return bnk.getBalance();
		}
		else {
			balance=balance-amount;
			acc.setBalance(String.valueOf(balance));
			return acc;
		}
	}
}
