package com.cg.cpg.dao;

import com.cg.cpg.dto.Bank;
import com.cg.cpg.exception.BankException;

public interface BankDAO {
	public Bank addCustomer(Bank bnk) throws BankException;
	public Bank getCustomer(String accono) throws BankException;
	public String ShowBalance(Bank bnk) throws BankException;
	public Bank  deposit(int amount, Bank bnk) throws BankException;
	public Bank  withdraw(int amount, Bank bnk) throws BankException;
}
