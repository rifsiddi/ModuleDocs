package com.cg.eis.exception;

public class EmployeeeException extends Exception {
	public EmployeeeException(String message)
	{
		System.out.println(message);
	}

}
