package com.cg.eis.service;

import com.cg.eis.bean.Employeee;
import com.cg.eis.dao.EmployeeeDao;
import com.cg.eis.dao.EmployeeeDaoImpl;
import com.cg.eis.exception.EmployeeeException;
import com.cg.eis.validation.DataValidator;

public class EmployeeeServiceImpl implements EmployeeeService {

	EmployeeeDao dao;
	DataValidator validator;

	public EmployeeeServiceImpl() {
		dao = new EmployeeeDaoImpl();
		validator = new DataValidator();

	}

	@Override
	public Employeee addEmployeeDetails(Employeee emp) throws EmployeeeException {
		boolean res1 = validator.validateEmpId(emp.getEmployeeId());
		boolean res2 = validator.validateName(emp.getEmployeeName());
		boolean res3 = validator.validateSalary(emp.getSalary());
		boolean res4 = validator.validateDesignation(emp.getDesignation());
		if (res1 == true) {
			throw new EmployeeeException("Employee Id should be six digit long");
		} else if (res2 == true) {
			throw new EmployeeeException(
					"Employee name should contain a starting uppercase letter and atleast 4 characters only ");
		} else if (res3 == true) {
			throw new EmployeeeException("Employee salary should be of atleast 4 digit");
		} else if (res4 == true) {
			throw new EmployeeeException("Employee designation is not appropriate");
		} else {// TODO Auto-generated method stub
			return dao.addEmployeeDetails(emp);
		}
	}

	@Override
	public String getInsuranceScheme(String employeeId) throws EmployeeeException {
		// TODO Auto-generated method stub
	//	boolean res5=validator.validateList();
		return dao.getInsuranceScheme(employeeId);
	}

	@Override
	public Employeee displayEmployeeDetail(String employeeId) throws EmployeeeException {
		// TODO Auto-generated method stub
		return dao.displayEmployeeDetail(employeeId);
	}

}
