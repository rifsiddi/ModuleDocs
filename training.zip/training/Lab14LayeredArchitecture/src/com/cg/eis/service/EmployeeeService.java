package com.cg.eis.service;

import com.cg.eis.bean.Employeee;
import com.cg.eis.exception.EmployeeeException;

public interface EmployeeeService {
	public Employeee addEmployeeDetails(Employeee emp) throws EmployeeeException;

	public String getInsuranceScheme(String employeeId) throws EmployeeeException;

	public Employeee displayEmployeeDetail(String employeeId) throws EmployeeeException;

}
