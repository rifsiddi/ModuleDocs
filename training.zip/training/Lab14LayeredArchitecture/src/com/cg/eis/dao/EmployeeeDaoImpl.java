package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employeee;
import com.cg.eis.exception.EmployeeeException;

public class EmployeeeDaoImpl implements EmployeeeDao {

	private static Map<String, Employeee> employeee = new HashMap<>();

	@Override
	public Employeee addEmployeeDetails(Employeee emp) throws EmployeeeException {
		if (employeee.containsKey(emp.getEmployeeId())) {
			throw new EmployeeeException("Employee with similar id already exist");
		} else {
			employeee.put(emp.getEmployeeId(), emp);
			return emp;
		}
	}

	@Override
	public String getInsuranceScheme(String employeeId) throws EmployeeeException {
		Employeee emp1 = employeee.get(employeeId);
		if (emp1 == null) {
			throw new EmployeeeException("Employee does not exist");

		} else {
			return emp1.getInsuranceScheme();
		}
	}

	@Override
	public Employeee displayEmployeeDetail(String employeeId) throws EmployeeeException {
		Employeee emp2 = employeee.get(employeeId);
		if (emp2 == null) {
			throw new EmployeeeException("Employee does not exist");
		} else {
			return emp2;
		}
	}

}
