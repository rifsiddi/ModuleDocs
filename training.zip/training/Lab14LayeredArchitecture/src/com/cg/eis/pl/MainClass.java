package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employeee;
import com.cg.eis.exception.EmployeeeException;
import com.cg.eis.service.EmployeeeService;
import com.cg.eis.service.EmployeeeServiceImpl;

public class MainClass {

	public static void main(String[] args) throws EmployeeeException {
		EmployeeeService service = new EmployeeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("enter your choice:");
			System.out.println("1)Add employee details");
			System.out.println("2)Display insurance scheme");
			System.out.println("3)Display details");
			System.out.println("4)Exit");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				Employeee e1 = acceptEmployeeDetails();
				try {
					e1 = service.addEmployeeDetails(e1);
					System.out.println("Employee added ......");
				} catch (EmployeeeException e) {
					e.getMessage();
				}
				break;
			case 2:
				System.out.println("Enter employee Id:");
				try {
					String empid=sc.next();
					String e2=service.getInsuranceScheme(empid);
					System.out.println(e2);
				} catch (Exception e) {
					e.getMessage();
				}
				break;
			case 3:
				System.out.println("Enter employeeId;");
				try {
					String empid=sc.next();
					e1=service.displayEmployeeDetail(empid);
					System.out.println(e1);
				} catch (Exception e) {
					e.getMessage();
				}
				break;
			case 4:
				System.exit(0);
				break;
			default:
				System.out.println("invalid input");
				break;
			}
		} while (true);
	}

	private static Employeee acceptEmployeeDetails() throws EmployeeeException{
		String insuranceScheme="";
		Scanner sc1 = new Scanner(System.in);
		Employeee emp1 = new Employeee();

		System.out.println("Enter employeeId:");
		String employeeId = sc1.next();
		emp1.setEmployeeId(employeeId);

		System.out.println("Enter employee name:");
		String employeeName = sc1.next();
		emp1.setEmployeeName(employeeName);

		System.out.println("Enter eemployee salary ");
		int salary = sc1.nextInt();
		emp1.setSalary(salary);

		System.out.println("Enter employee designation:");
		String designation = sc1.next();
		emp1.setDesignation(designation);

		if (salary > 5000 && salary < 20000 && designation.equalsIgnoreCase("SystemAssociate")) {
			insuranceScheme = "Scheme A";
			emp1.setInsuranceScheme(insuranceScheme);
		} else if (salary >= 20000 && salary < 40000 && designation.equalsIgnoreCase("Programmer")) {
			insuranceScheme = "Scheme B";
			emp1.setInsuranceScheme(insuranceScheme);
		} else if (salary >= 40000 && designation.equalsIgnoreCase("Manager")) {
			insuranceScheme = "Scheme C";
			emp1.setInsuranceScheme(insuranceScheme);
		} 
		else if(salary< 5000 && designation.equalsIgnoreCase("Clerk"))
		{
			insuranceScheme = "No Scheme";
			emp1.setInsuranceScheme(insuranceScheme);
		}
		else {
			throw new EmployeeeException("please re-enter your salary or designation");
		}
	
		//System.out.println(emp1);
		return emp1;
	}
}
