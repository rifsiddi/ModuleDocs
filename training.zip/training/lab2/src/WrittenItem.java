import java.util.ArrayList;
import java.util.List;

public abstract class WrittenItem extends Item {
	
	
	public WrittenItem() {
		
	}
	
	public WrittenItem(String author)
	{
		super();
		this.author=author;
		
	}
	
	public WrittenItem(int identificationNumber, String title, int numberOfCopies,String author)
	{
		super(identificationNumber,title,numberOfCopies);
		this.author=author;
	}
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+""+author;
		
	}
	
	@Override
	public void CheckOut(int identificationNumber)
	{
	}
	@Override
	public void CheckIn(int identificationNumber) {
	
	}
	
	@Override
	public void print()
	{
		
	}
	
	@Override
	public List<String> addItem()
	{
		List<String> list= new ArrayList<>();
			return list;
		
	}
	
	@Override
	public boolean equals(Object obj)
	{
		return false;
		
	}

}
