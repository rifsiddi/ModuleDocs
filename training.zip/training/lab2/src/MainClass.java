import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainClass {

	String title, author, yearPublished, director, genre, artist;
	int identificationNo, noOfCopies, runtime, year;
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		List<Book> list1 = new ArrayList<Book>();
		List<JournalPaper> list2 = new ArrayList<JournalPaper>();
		List<Video> list3 = new ArrayList<Video>();
		List<CD> list4 = new ArrayList<CD>();

		Book bbk = new Book();
		JournalPaper jp = new JournalPaper();
		Video v = new Video();
		CD cd = new CD();

		MainClass mc = new MainClass();
		Scanner sc1 = new Scanner(System.in);
		do {
			System.out.println("Enter your options");
			System.out.println("1)Add an item 2)Display items 3)exit");
			int opt = sc1.nextInt();
			switch (opt) {
			case 1:
				System.out.println("select 1)add book 2)add journal 3)Video detail 4)CD detail");
				int input = sc1.nextInt();

				if (input == 1) {
					bbk = mc.acceptBookDetail();
					list1.add(bbk);
					System.out.println("Book added successfully");
				} else if (input == 2) {
					jp = mc.acceptJournalDetail();
					list2.add(jp);
					System.out.println("journal detail added successfully...");
				} else if (input == 3) {
					v = mc.acceptVideoDetail();
					list3.add(v);
					System.out.println("video details added successfully...");
				} else if (input == 4) {
					cd = mc.acceptCdDetail();
					list4.add(cd);
					System.out.println("CD details added successfullyy....");
				} else {
					System.out.println(".....");
				}

				break;
			case 2:
				System.out.println("1)book 2)journal 3)video 4)CD");
				int opt2 = sc1.nextInt();
				if (opt2 == 1) {
					for (Book bk : list1) {
						System.out.println(bk.getIdentificationNumber() + " " + bk.getAuthor() + " " + bk.getTitle()
								+ " " + bk.getNumberOfCopies());
					}
				} else if (opt2 == 2) {
					for (JournalPaper bk : list2) {
						System.out.println(bk.getIdentificationNumber() + " " + bk.getAuthor() + " " + bk.getTitle()
								+ " " + bk.getNumberOfCopies() + " " + bk.getYearPublished());
					}
				} else if (opt2 == 3) {
					for (Video vv : list3) {
						System.out.println(vv.getIdentificationNumber() + " " + vv.getDirector() + " " + vv.getTitle()
								+ " " + vv.getNumberOfCopies() + " " + vv.getGenre() + " " + vv.getRuntime() + " "
								+ vv.getYear());
					}
				} else if (opt2 == 4) {
					for (CD vv : list4) {
						System.out.println(
								vv.getIdentificationNumber() + " " + vv.getTitle() + " " + vv.getNumberOfCopies() + " "
										+ vv.getGenre() + " " + vv.getRuntime() + " " + vv.getArtist());
					}
				} else {

				}
				break;
			case 3:
				System.exit(0);
				break;
			default:
				break;
			}
			
		} while (true);
	}

	private CD acceptCdDetail() {
		CD v = new CD();
		System.out.println("Enter identification number");
		identificationNo = sc.nextInt();
		v.setIdentificationNumber(identificationNo);
		System.out.println("Enter title");
		title = sc.next();
		v.setTitle(title);
		System.out.println("Enter no of copies");
		noOfCopies = sc.nextInt();
		v.setNumberOfCopies(noOfCopies);
		System.out.println("enter runtime:");
		runtime = sc.nextInt();
		v.setRuntime(runtime);
		System.out.println("Enter artist name:");
		artist = sc.next();
		v.setArtist(artist);
		System.out.println("Enter genre type");
		genre = sc.next();
		v.setGenre(genre);
		return v;

	}

	private Video acceptVideoDetail() {
		Video v = new Video();
		System.out.println("Enter identification number");
		identificationNo = sc.nextInt();
		v.setIdentificationNumber(identificationNo);
		System.out.println("Enter title");
		title = sc.next();
		v.setTitle(title);
		System.out.println("Enter no of copies");
		noOfCopies = sc.nextInt();
		v.setNumberOfCopies(noOfCopies);
		System.out.println("enter runtime:");
		runtime = sc.nextInt();
		v.setRuntime(runtime);
		System.out.println("Enter director name:");
		director = sc.next();
		v.setDirector(director);
		System.out.println("Enter genre type:");
		genre = sc.next();
		v.setGenre(genre);
		System.out.println("Enter the year of video published");
		year = sc.nextInt();
		v.setYear(year);
		return v;

	}

	private JournalPaper acceptJournalDetail() {
		JournalPaper bk = new JournalPaper();
		System.out.println("Enter identification number");
		identificationNo = sc.nextInt();
		bk.setIdentificationNumber(identificationNo);
		System.out.println("Enter title");
		title = sc.next();
		bk.setTitle(title);
		System.out.println("Enter no of copies");
		noOfCopies = sc.nextInt();
		bk.setNumberOfCopies(noOfCopies);
		System.out.println("Enter author name");
		author = sc.next();
		bk.setAuthor(author);
		System.out.println("Enter year of published");
		yearPublished = sc.next();
		bk.setYearPublished(yearPublished);
		return bk;
	}

	private Book acceptBookDetail() {
		Book bk = new Book();
		System.out.println("Enter identification number");
		identificationNo = sc.nextInt();
		bk.setIdentificationNumber(identificationNo);
		System.out.println("Enter title");
		title = sc.next();
		bk.setTitle(title);
		System.out.println("Enter no of copies");
		noOfCopies = sc.nextInt();
		bk.setNumberOfCopies(noOfCopies);
		System.out.println("Enter author name");
		author = sc.next();
		bk.setAuthor(author);
		return bk;
	}

}
