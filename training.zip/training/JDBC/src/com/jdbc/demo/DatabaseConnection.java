package com.jdbc.demo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
	public static Connection getConnection() throws IOException {
		String url;
		String username;
		String pwd;
		String driver;
		Connection conn=null;
		try {
			FileInputStream fis= new FileInputStream("./resources/jdbc.properties");
			Properties prop= new Properties();
			prop.load(fis);
			driver=prop.getProperty("driver");
			pwd=prop.getProperty("pwd");
			url=prop.getProperty("url");
			username=prop.getProperty("username");
			Class.forName(driver);
			conn=DriverManager.getConnection(url,  username, pwd);
			System.out.println("Connected to DB...");
			
		}
		catch(ClassNotFoundException e) {
			System.out.println("Class not found...");
		}
		catch(SQLException e) {
			System.out.println("Not connected to DB...");
			System.out.println(e.getMessage());
		}
		return conn;
	}
}
