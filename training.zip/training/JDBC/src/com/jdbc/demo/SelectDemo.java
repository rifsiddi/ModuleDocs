package com.jdbc.demo;

import java.io.IOException;
import java.sql.*;

public class SelectDemo {
	public static void main(String[] args) throws IOException {
		Connection con= DatabaseConnection.getConnection();
		Statement st;
	
			try {
				st=con.createStatement();
				ResultSet res= st.executeQuery("select stud_name, rollno,address, phone_number, course_code from student_details");
				while(res.next())  {
					int rn= res.getInt(2);
					String name=res.getString(1);
					String address= res.getString(3);
					String phone= res.getString("Phone_number");
					int cc=res.getInt("course_code");
					System.out.println(rn +" "+name+" "+address+" "+phone+" "+cc);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}
