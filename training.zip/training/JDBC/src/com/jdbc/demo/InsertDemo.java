package com.jdbc.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertDemo {
	public static void main(String[] args) throws IOException {
		Connection con=DatabaseConnection.getConnection();
		String sql="insert into student_details"+"(rollno,stud_name,enrolled_date,course_code,phone_number)"+"values(?,?,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, 101);
			ps.setString(2,  "Vidya");
			ps.setInt(3, 1);
			ps.setString(4,  "9210320");
			int row= ps.executeUpdate();
			System.out.println(row +" inserted...");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
}
}
