package com.jdbc.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateDemo {
	public static void main(String[] args) throws IOException {
		Connection con=DatabaseConnection.getConnection();
		String sql="update student_details"+"set address=? ,course_code=? ,where rollno=?";
		//String sql="delete from student_details where rollno=?";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1,"Mumbai");
			ps.setInt(2, 5);
			ps.setInt(3, 101);
			//ps.setInt(1, 101);
			int row= ps.executeUpdate();
			System.out.println(row +" inserted...");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
}
}
