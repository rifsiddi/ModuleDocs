package com.jdbc.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ScrollableResultSetDemo {
	public static void main(String[] args) throws IOException {
		Connection con= DatabaseConnection.getConnection();
		Statement st;
	
			try {
				st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet res= st.executeQuery("select stud_name, rollno,"+"address, phone_number, course_code"+" from student_details");
				res.afterLast();
				while(res.previous())  {
					int rn= res.getInt(2);
					String name=res.getString(1);
					String address= res.getString(3);
					String phone= res.getString("Phone_number");
					int cc=res.getInt("course_code");
					System.out.println(rn +" "+name+" "+address+" "+phone+" "+cc);
				}
					System.out.println("print first record:");
					res.first();
					int rn=res.getInt("rollno");
					String name=res.getString("stud_name");
					String address=res.getString("address");
					System.out.println(rn+" "+name+ " "+address);
					
					System.out.println("print 5th record:");
					res.absolute(5);
					rn=res.getInt("rollno");
					name=res.getString("stud_name");
					address=res.getString("address");
					System.out.println(rn+" "+name+ " "+address);
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		
	}
}
