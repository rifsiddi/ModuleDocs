package com.jdbc.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PreparedStatementDemo {
	public static void main(String[] args) throws IOException {
		Connection con= DatabaseConnection.getConnection();
		String sql="select stud_name,rollno,phone_number "
				+ " from student_details where course_code=?";
		
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(1, 2);
				ResultSet res=ps.executeQuery();
				if(res.next()==false) {
					
				}
				while(res.next()) {
					int rn= res.getInt("rollno");
					String name=res.getString("stud_name");
					String phno= res.getString("phone_number");
					System.out.println(rn+" "+name+" "+phno);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}
}
