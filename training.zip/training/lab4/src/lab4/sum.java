package lab4;
import java.util.*;

public class sum {
	public int Sum(int n) {
		int sum=0;
		while(n>0)
		{
			int c=n%10;
			int b=c*c*c;
			sum+=b;
			n=n/10;
		}
		System.out.println("Sum of the cube of the digit is: "+sum);
		return sum;
	}
	public static void main(String[] args) {
		sum s= new sum();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int s1=sc.nextInt();
		int res=s.Sum(s1);
		sc.close();
	}

}
