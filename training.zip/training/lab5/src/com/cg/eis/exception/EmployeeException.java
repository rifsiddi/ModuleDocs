package com.cg.eis.exception;
import java.util.Scanner;
public class EmployeeException extends Exception{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your salary:");
		int n=s.nextInt();
		try {
			if(n<3000)
			{
				throw new EmployeeException();
			}
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
	}

}
