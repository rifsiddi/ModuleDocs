package lab5;

import java.util.Scanner;

public class FibonacciSequence {

	public static void main(String[] args) {
		try {
			int f1 = 1;
			int f2 = 1;
			int f3 = 0;

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the nth value of the Fibonacci sequence");
			int n = sc.nextInt();
			System.out.println("Enter your choice");
			System.out.println("1)Fibonacci using non-recursive function");
			System.out.println("2)Fibonacci using recursive function");
			int opt = sc.nextInt();
			switch (opt) {
			case 1:
				System.out.println("Fibonacci using non-recursive function");
				for (int i = 0; i < n - 2; i++) {
					f3 = f1 + f2;
					f1 = f2;
					f2 = f3;
				}
				System.out.println(f3);

				break;
			case 2:
				System.out.println("Fibonacci using recursive function");
				System.out.println(fib(n));

				break;
			default:
				System.out.println("default value entered");
				break;
			}
			sc.close();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	private static int fib(int n) {
		if (n <= 1)
			return n;

		return fib(n - 1) + fib(n - 2);

	}

}

