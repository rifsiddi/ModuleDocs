package lab5;

import java.util.Scanner;

public class ValidateAge {
	
	public static void main(String[] args) throws EmployeeException
	{
		try
		{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		sc.close();
		if(age<0)
		{
			throw new EmployeeException("Age cannot be negative");
		}
		else if(age<=15)
		{
			throw new EmployeeException("Age should be greater than 15");
		}
		else
		{
			System.out.println("AGE: "+ age);	
		}
		
		}
		catch(EmployeeException e)
		{
		e.getMessage();
		}
	}

}

