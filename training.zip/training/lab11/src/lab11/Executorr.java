package lab11;

import java.time.LocalTime;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Executorr implements Callable<Integer> {
	@Override
	public Integer call() throws Exception {
		try {
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number of times you want to run the timer:");
		String s= sc.nextLine();
		n=Integer.parseInt(s);
		if(n>0) {
		for(int i=1;i<=n;i++){
		LocalTime time=LocalTime.now();
		System.out.println(time);
		Thread.sleep (10000);
		}
		}
		else {
			System.out.println("Enter positive integer number");
		
		}
	}
		catch(NumberFormatException e) {
        	System.out.println("Enter a valid natural number");
        }
        catch (InterruptedException interruptedException)
        {
        	System.out.println( "Thread is interrupted when it is sleeping" +interruptedException);
     
        }
		return null;
	}
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Callable<Integer> task = new Executorr();
		ExecutorService st = Executors.newFixedThreadPool(5);
		Future<Integer> result = st.submit(task);
	}
}