package com.cg.ams.bean;

import java.util.ArrayList;
import java.util.List;

public class CustomerAccount 
{
	private static int acc_no=123450;
	private String a_name;
	private String phone_number;
	private String address;
	private double balance;
	private List<String> transactions;
	private String username;
	private String pwd;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public CustomerAccount()
	{
		CustomerAccount.setAcc_no();
		transactions=new ArrayList<String>();
	}
	public static int getAcc_no() {
		return acc_no;
	}
	public static void setAcc_no() {
		CustomerAccount.acc_no = acc_no+1;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<String> getTransactions() {
		return transactions;
	}
	public void setTransactions(String transaction) {
		this.transactions.add(transaction);
	}
	public String toString()
	{
		return "\nAccount No.="+this.getAcc_no()+"\nName="+this.getA_name()+"\nusername"+this.getUsername()+
			"\nPhone No.="+this.getPhone_number()+"\nAddress="+this.getAddress()
				+"\nBalance="+this.getBalance()+
				"\nNo. of Transactions done="+this.getTransactions().size();
	}
}
