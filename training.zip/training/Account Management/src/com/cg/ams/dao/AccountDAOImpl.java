package com.cg.ams.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ams.bean.CustomerAccount;
import com.cg.ams.exception.AccountException;

public class AccountDAOImpl implements AccountDAO 
{
	private static Map<Integer,CustomerAccount> accounts=new HashMap<>();
	@Override
	public CustomerAccount addAccount(CustomerAccount ac) throws AccountException 
	{
		accounts.put(ac.getAcc_no(), ac);
		return ac;
	}

	@Override
	public CustomerAccount depositAmount(double amount, CustomerAccount ac) throws AccountException 
	{
		double bal=ac.getBalance();
		ac.setBalance(bal+amount);
		return ac;
	}

	@Override
	public CustomerAccount withdrawAmount(double amount, CustomerAccount ac) throws AccountException 
	{
		double bal=ac.getBalance();
		if(bal>=amount)
		{
			ac.setBalance(bal-amount);
			//System.out.println(ac.getBalance());
			return ac;
		}
		else
			throw new AccountException("Not enough money in the wallet.");
		
	}

	@Override
	public boolean fundTransfer(double amount, CustomerAccount to_acc, CustomerAccount from_acc) throws AccountException 
	{
		AccountDAO dao=new AccountDAOImpl();
		try 
		{
			dao.withdrawAmount(amount, from_acc);
			dao.depositAmount(amount, to_acc);
			return true;
		}
		catch (AccountException e) 
		{
			throw new AccountException("Fund Transfer failed!");
		}
	}

	@Override
	public List<String> printTransactions(CustomerAccount ac) throws AccountException 
	{
		return ac.getTransactions();
	}

	@Override
	public double showBalance(CustomerAccount ac) throws AccountException 
	{
		return ac.getBalance();
	}

	@Override
	public CustomerAccount getAccount(int acc_no) throws AccountException 
	{
		return accounts.get(acc_no);
	}
	
}
