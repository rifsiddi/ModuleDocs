package com.cg.ams.pl;


import java.util.List;
import java.util.Scanner;
import com.cg.ams.bean.CustomerAccount;
import com.cg.ams.service.AccountService;
import com.cg.ams.service.AccountServiceImpl;
import com.cg.ams.exception.AccountException;

public class MainClass 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		AccountService service=new AccountServiceImpl();
		for(;;)
		{
			CustomerAccount ac;
			System.out.println("Press\n1. Add account\n2. Withdraw Amount\n"
				+"3. Deposit Amount\n4. Fund Transfer\n5. Print All Transactions"
				+"\n6. Show Current Balance\n7. Show Customer Details\n8. Exit");
			System.out.println("Enter Option:");
			int option=sc.nextInt();
			switch(option)
			{
			case 1:
				try
				{
					ac=acceptDetails();
					service.addAccount(ac);
					System.out.println("Account added!");
					System.out.println("Your account number is "+ac.getAcc_no());
				}
				catch (AccountException e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 2:
				try 
				{
					System.out.println("Enter account number:");
					int acc_no=sc.nextInt();
					System.out.println("Enter amount to withdraw:");
					double amount=sc.nextDouble();
					ac=service.getAccount(acc_no);
					service.withdrawAmount(amount, ac);
					ac.setTransactions("Withdrawn Rs."+amount+
							" from the account");
					System.out.println("Withdraw Successful");
					System.out.println("Balance="+service.showBalance(ac));
				}
				catch (AccountException e) 
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 3:
				try 
				{
					System.out.println("Enter account number:");
					int acc_no=sc.nextInt();
					System.out.println("Enter amount to deposit:");
					double amount=sc.nextDouble();
					ac=service.getAccount(acc_no);
					service.depositAmount(amount, ac);
					ac.setTransactions("Deposited Rs."+amount+
							" from the account");
					System.out.println("Deposit Successful");
					System.out.println("Balance="+service.showBalance(ac));
				}
				catch (AccountException e) 
				{
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				try 
				{
					System.out.println("Enter account number of sender:");
					int acc_no=sc.nextInt();
					System.out.println("Enter amount to transfer:");
					double amount=sc.nextDouble();
					System.out.println("Enter account no of receiver:");
					int to_acc=sc.nextInt();
					ac=service.getAccount(acc_no);
					CustomerAccount ac1=service.getAccount(to_acc);
					if(service.fundTransfer(amount, ac1, ac))
					{
						ac.setTransactions("Transferred Rs."+amount+
							" from the account to "+ac1.getA_name());
						System.out.println("Transfer Successful");
						System.out.println("Balance="+service.showBalance(ac));
					}
					else
						System.out.println("Transfer falied!");
						
				}
				catch (AccountException e) 
				{
					System.out.println(e.getMessage());
				}
				break;
			case 5:
				try 
				{
					System.out.println("Enter account number:");
					int acc_no=sc.nextInt();
					ac=service.getAccount(acc_no);
					List<String> transaction=service.printTransactions(ac);
					for(String str:transaction)
					{
						System.out.println(str+"\n");
					}
				}
				catch (AccountException e) 
				{
					System.out.println(e.getMessage());
				}
				break;
			case 6:
				try
				{
					System.out.println("Enter account number:");
					int acc_no=sc.nextInt();
					ac=service.getAccount(acc_no);
					System.out.println("Current Balance is Rs. "
						+service.showBalance(ac));
				}
				catch(AccountException ex)
				{
					System.out.println(ex.getMessage());
				}
				break;
				
			case 7:
				System.out.println("Enter account number:");
				int acc_no=sc.nextInt();
				try {
					ac=service.getAccount(acc_no);
					System.out.println("Employee Details: "+ac.toString());
				}catch(AccountException e)
				{
					System.out.println(e.getMessage());
				}
				break;
			
			case 8:
				System.out.println("Thank You!");
				System.exit(0);
			default:
				System.out.println("Invalid input");
			}
		}
	}
	public static CustomerAccount acceptDetails()
	{
		CustomerAccount ac=new CustomerAccount();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		String name=sc.nextLine();
		ac.setA_name(name);
		System.out.println("Enter phone no.:");
		String phn_no=sc.next();
		ac.setPhone_number(phn_no);
		System.out.println("Enter Address:");
		String address=sc.next()+sc.nextLine();
		ac.setAddress(address);
		System.out.println("Enter initial balance:");
		double bal=sc.nextDouble();
		ac.setBalance(bal);
		return ac;
	}

}
