package com.capg.ems.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capg.ems.dto.Employee;
import com.capg.ems.exception.EmployeeException;

public  class EmployeeDAOImpl implements EmployeeDAO {

	private static Map<String,Employee> employees=new HashMap<>();
	
	@Override
	public Employee addEmployee(Employee emp)  throws EmployeeException {
		if(employees.containsKey(emp.getEmpId()))
		{
			throw new EmployeeException("Employee id already exist");
			
		}
		else
			{employees.put(emp.getEmpId(), emp);
		return emp;}
	}

	@Override
	public List<Employee> getEmployees()  throws EmployeeException {
		
		Collection<Employee> list=employees.values();
		List<Employee> empList=new ArrayList<>(list);
		return empList;
	
	}

	@Override
	public Employee deleteEmployee(String empid) throws EmployeeException {
		Employee emp=employees.remove(empid);
		if(emp==null)
		{
			throw new EmployeeException("Employee not found");
		}
		else
		{
		return emp;}
	}

	@Override
	public Employee getEmployeeById(String empid) throws EmployeeException {
		Employee emp= employees.get(empid);
		if(emp.equals(null))
		{
			throw new EmployeeException("Employee not found");
		}
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		employees.replace(emp.getEmpId(),emp);
		if(emp.getEmpId().equals(null))
		{
			throw new EmployeeException("Employee not found");
		}
		return emp;
	}

}
