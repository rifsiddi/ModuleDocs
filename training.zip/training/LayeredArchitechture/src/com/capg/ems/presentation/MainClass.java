package com.capg.ems.presentation;


import java.util.List;
import java.util.Scanner;

import com.capg.ems.dto.Employee;
import com.capg.ems.exception.EmployeeException;
import com.capg.ems.service.DataValidator;
import com.capg.ems.service.EmployeeService;
import com.capg.ems.service.EmployeeServiceImpl;

public class MainClass {

	
	//accept user details
	public static Employee acceptEmployeeDetails()
	{
		Employee emp= new Employee();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter employee Id");
		String id= sc.next();
		emp.setEmpId(id);
		
		System.out.println("Enter name");
		String name=sc.next();
		emp.setName(name);
		
		System.out.println("enter salary");
		double sal=sc.nextDouble();
		emp.setSalary(sal);
		
		System.out.println("enter deptCode");
		int code=sc.nextInt();
		emp.setDeptCode(code);
		
		System.out.println("enter location");
		String loc= sc.next();
		emp.setLocation(loc);
		
		System.out.println("enter mobileNo");
		String mobile= sc.next();
		emp.setMobileNo(mobile);
		
		return emp;
		
	}
	
	public static void displayEmployees(List<Employee> empList)
	{
		for(Employee e:empList)
		{
			System.out.println(e.getEmpId()+"");
			System.out.println(e.getName()+"");
			System.out.println(e.getDeptCode()+"");
			System.out.println(e.getLocation()+"");
			System.out.println(e.getMobileNo()+"");
			System.out.println(e.getSalary()+"");
		}
	}
	
	public static void main(String[] args){
		EmployeeService service = new EmployeeServiceImpl();
		
		do
		{
			
	    System.out.println("1) Add employee");
		System.out.println("2) Display employee List");
		System.out.println("3) delete employee");
		System.out.println("4) Display employee by id");
		System.out.println("5) Update employee");
		System.out.println("6) Exit");
		System.out.println("enter option");
		
		
		Scanner sc= new Scanner(System.in);
		int option = sc.nextInt();
		switch(option)
		{
		case 1:
			Employee emp= acceptEmployeeDetails();
			try {
			emp=service.addEmployee(emp);
			System.out.println("employee added .....");
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
			
		case 2:
			try {
			List<Employee> list=service.getEmployees();
			displayEmployees(list);
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("Enter the empid to delete record");
			
			try
			{
				String empid=sc.next();
				emp= service.deleteEmployee(empid);
				System.out.println("Employee deleted successfullly");
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 4:
			System.out.println("Enter the empid to view record");
			
			try
			{	DataValidator validator = new DataValidator();
				String empid=sc.next();
				boolean res=validator.validateEmpId(empid);
				if(res==true)
				{
				emp= service.getEmployeeById(empid);
				System.out.println("retrieved successfully"+ emp);
				}
				else
				{
					System.out.println("EMPID should be six digit long");
				}
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
		case 5:
			Employee emp1= acceptEmployeeDetails();
			try {
			emp=service.updateEmployee(emp1);
			System.out.println("employee updated successfully .....");
			}
			catch(EmployeeException e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case 6:
			sc.close();
			System.exit(0);
			
		default:
			System.out.println();
			break;
		}
	}while(true);
			
		
	}

}
