package com.capg.ems.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.ems.dto.Employee;

public class DataValidator {

	
	public boolean validateName(String name) {
		
		Pattern pattern= Pattern.compile("[A-Z][a-z]{4,}");
		Matcher match=pattern.matcher(name);
		return match.matches();
	}
	public boolean validateMobileNo(String mobile) {

		Pattern pattern= Pattern.compile("[7-9][0-9]{9}");
		Matcher match=pattern.matcher(mobile);
		return match.matches();
	}
	public boolean validateLocation(String location) {
		if(location.equalsIgnoreCase("Mumbai") || location.equalsIgnoreCase("chennai")|| location.equalsIgnoreCase("Pune")
	||location.equalsIgnoreCase("Banglore"))
			return true;
		else
			return false;
		
	}
	public boolean validateEmpId(String id) {
		Pattern pattern= Pattern.compile("[0-9]{6}");
		Matcher match=pattern.matcher(id);
		return match.matches();
	}
	
	public boolean validateList(List<Employee> list)
	{
		if(list.isEmpty())
		{return true;}
		else
		{
			return false;
		}
		
	}
}
