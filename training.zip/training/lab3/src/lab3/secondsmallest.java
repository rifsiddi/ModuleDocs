package lab3;
import java.lang.reflect.Array;
import java.util.Arrays;

public class secondsmallest {
	public int getSecondSmallest(int arr[])
	{
		Arrays.sort(arr);;
		int element=arr[1];
		return element;
	}
	public static void main(String[] args) {
		int arr[]= {89,34,233,45,6,784,879};
		secondsmallest ss= new secondsmallest();
		int res= ss.getSecondSmallest(arr);
		System.out.println(res);
	}

}
