package lab3;
import java.util.Arrays;
public class ReverseSort {
	int[] Array(int n[]) {
		int b[]=n;
		int len=b.length;
		for(int i=0;i<len;i++)
		{
			String c=Integer.toString(b[i]);
			StringBuffer s= new StringBuffer(c);
			s.reverse();
			String d=s.toString();
			b[i]=Integer.parseInt(d);
		}
		Arrays.sort(b);
		return b;
	}
	/*public void getSorted(int array[])
	{
		/*String reverse="";
        int len=array.length;
        String[] arr= new String[len];
        for(int i=0;i<array.length;i++)
        {
        	int temp=array[i];
        	String temp1=Integer.toString(temp);
        	arr[i]=temp1;
        	
        }
        for(int j=0;j<arr.length;j++)
        {
        	String temp=arr[j];
        	for(int i=temp.length()-1;i>=0;i--)
        	{
        		reverse= reverse+temp.charAt(i);
        	}
        	arr[j]=reverse;
        	reverse="";
        }
        for (int i=0;i<arr.length;i++)
        {
        	String m=arr[i];
        	int k=Integer.valueOf(m);
        	array[i]=k;
        }
        Arrays.sort(arr);
        for(int m=0;m<arr.length;m++)
        {
        	System.out.println(arr[m]);
        }
	
	}*/
	public static void main(String[] args) {
		int[] n= new int[] {342,56,23,76,89};
		ReverseSort rs= new ReverseSort();
		int res[]=rs.Array(n);
		System.out.println(Arrays.toString(res));
		//rs.getSorted(array);
	}

}
