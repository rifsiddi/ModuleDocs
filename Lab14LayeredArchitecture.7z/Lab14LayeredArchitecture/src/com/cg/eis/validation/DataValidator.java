package com.cg.eis.validation;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.eis.bean.Employeee;

public class DataValidator {

	public boolean validateName(String name) {

		Pattern pattern = Pattern.compile("[A-Z][a-z]{4,}");
		Matcher match = pattern.matcher(name);
		return match.matches();
	}

	public boolean validateSalary(int salary) {
		String sal=Integer.toString(salary);
		Pattern pattern = Pattern.compile("[1-9][0-9]{4,}");
		Matcher match = pattern.matcher(sal);
		return match.matches();

	}

	public boolean validateDesignation(String designation) {
		if (designation.equalsIgnoreCase("SystemAssociate") || designation.equalsIgnoreCase("programmer")
				|| designation.equalsIgnoreCase("manager") || designation.equalsIgnoreCase("clerk"))
			return true;
		else
			return false;

	}

	public boolean validateEmpId(String id) {
		Pattern pattern = Pattern.compile("[0-9]{6}");
		Matcher match = pattern.matcher(id);
		return match.matches();
	}

//	public boolean validateList(List<Employeee> list) {
//		if (list.isEmpty()) {
//			return true;
//		} else {
//			return false;
//		}
//
//	}
}
