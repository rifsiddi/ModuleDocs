﻿import { Component } from '@angular/core';
import { Data } from './app.data';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn, Validators } 
from '@angular/forms';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent {

    d :Data={name:null,address:null,PinCode:null};

    useForm = new FormGroup({
        name: new FormControl(null,Validators.pattern('[A-Z][a-z]+')),
        address: new FormControl(),
        PinCode: new FormControl(null,Validators.pattern('[0-9]+'))
    });

    add(eForm:FormGroup):void
    {
        console.log("....."+this.useForm.value);
        this.d.name=this.useForm.controls["eid"].value;
        this.d.address=this.useForm.controls['ename'].value;
        this.d.PinCode=this.useForm.controls['esal'].value;
      
        
        }
 }