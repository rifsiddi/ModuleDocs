export class Data{
    
    name:string;
    address:string;
    PinCode:number;
    
}