package com.cg.ams.exception;

public class AccountException extends Exception 
{
	public AccountException(String str)
	{
		super(str);
	}
}
