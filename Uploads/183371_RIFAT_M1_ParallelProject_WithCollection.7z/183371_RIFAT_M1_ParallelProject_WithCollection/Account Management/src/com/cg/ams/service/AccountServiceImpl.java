package com.cg.ams.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.ams.bean.CustomerAccount;
import com.cg.ams.dao.AccountDAO;
import com.cg.ams.dao.AccountDAOImpl;
import com.cg.ams.exception.AccountException;

public class AccountServiceImpl implements AccountService 
{
	DataValidator validator;
	AccountDAO dao;
	public AccountServiceImpl() 
	{
		validator=new DataValidator();
		dao=new AccountDAOImpl();
	}
	
	@Override
	public CustomerAccount addAccount(CustomerAccount ac) throws AccountException 
	{
		if(!validator.validateName(ac.getA_name()))
		{
			try
			{
				throw new AccountException("Invalid Name");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validatePhoneNo(ac.getPhone_number()))
		{
			try
			{
				throw new AccountException("Invalid Phone Number");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.addAccount(ac);
	}

	@Override
	public CustomerAccount depositAmount(double amount, CustomerAccount ac) throws AccountException 
	{
		if(!validator.validateAmount(amount))
		{
			try
			{
				throw new AccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(ac.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.depositAmount(amount, ac);
	}

	@Override
	public CustomerAccount withdrawAmount(double amount, CustomerAccount ac) throws AccountException 
	{
		if(!validator.validateAmount(amount))
		{
			try
			{
				throw new AccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(ac.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.withdrawAmount(amount, ac);
	}

	@Override
	public boolean fundTransfer(double amount, CustomerAccount to_acc, CustomerAccount from_acc) throws AccountException 
	{
		if(!validator.validateAmount(amount))
		{
			try
			{
				throw new AccountException("Invalid amount"
						+ "(should be in decimal)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(to_acc.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		else if(!validator.validateAccNo(from_acc.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.fundTransfer(amount, to_acc, from_acc);
	}

	@Override
	public List<String> printTransactions(CustomerAccount ac) throws AccountException 
	{
		if(!validator.validateAccNo(ac.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.printTransactions(ac);
	}

	@Override
	public double showBalance(CustomerAccount ac) throws AccountException 
	{
		if(!validator.validateAccNo(ac.getAcc_no()))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		return dao.showBalance(ac);
	}

	@Override
	public CustomerAccount getAccount(int acc_no) throws AccountException 
	{
		if(!validator.validateAccNo(acc_no))
		{
			try
			{
				throw new AccountException("Invalid Account Number"
						+ "(should be of 6 digits, numbers only)");
			}
			catch(AccountException ex)
			{
				throw ex;
			}
		}
		
		return dao.getAccount(acc_no);
	}
}
