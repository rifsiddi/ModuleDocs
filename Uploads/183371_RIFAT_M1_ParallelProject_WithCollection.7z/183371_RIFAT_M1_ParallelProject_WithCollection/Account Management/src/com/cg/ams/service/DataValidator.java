package com.cg.ams.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator 
{
	public boolean validateAccNo(int acc_no)
	{
		Pattern p=Pattern.compile("[0-9]{6}");
		Matcher m=p.matcher(Integer.toString(acc_no));
		return m.matches();
	}
	
	public boolean validateAmount(double amt)
	{
		Pattern p=Pattern.compile("[0-9.]{3,}");
		Matcher m=p.matcher(Double.toString(amt));
		return m.matches();
	}
	
	public boolean validateName(String name)
	{
		Pattern p=Pattern.compile("[A-Z]{1}[a-z ]{2,}");
		Matcher m=p.matcher(name);
		return m.matches();
	}
	
	public boolean validatePhoneNo(String phone_number)
	{
		Pattern p=Pattern.compile("[7-9]{1}[0-9]{9}");
		Matcher m=p.matcher(phone_number);
		return m.matches();
	}
}
