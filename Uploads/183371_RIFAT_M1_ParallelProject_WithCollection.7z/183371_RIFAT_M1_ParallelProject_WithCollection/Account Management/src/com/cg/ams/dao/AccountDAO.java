package com.cg.ams.dao;

import java.util.List;

import com.cg.ams.bean.CustomerAccount;
import com.cg.ams.exception.AccountException;

public interface AccountDAO
{
	public CustomerAccount addAccount(CustomerAccount ac) throws AccountException;
	public CustomerAccount depositAmount(double amount, CustomerAccount ac) throws AccountException;
	public CustomerAccount withdrawAmount(double amount, CustomerAccount ac) throws AccountException;
	public boolean fundTransfer(double amount, CustomerAccount to_acc, CustomerAccount from_acc) throws AccountException;
	public List<String> printTransactions(CustomerAccount ac) throws AccountException;
	public double showBalance(CustomerAccount ac) throws AccountException;
	public CustomerAccount getAccount(int acc_no) throws AccountException;
}
