import { Mobile } from "./mobile";
import { BasicPhone } from "./basicphone";
import { SmartPhone } from "./smartphone";

//let bPhone= new BasicPhone();
//let sPhone= new SmartPhone();

let basicArray:BasicPhone[]=[
    {mobileId:101,mobileName:"Nokia",mobileCost:2000,mobileType:"BasicPhone"},
    {mobileId:102,mobileName:"HTC",mobileCost:2500,mobileType:"BasicPhone"}
];

let smartArray:SmartPhone[]=[
    {mobileId:1001,mobileName:"MI",mobileCost:20000,mobileType:"SmartPhone"},
    {mobileId:1002,mobileName:"Apple",mobileCost:25000,mobileType:"SmartPhone"}
];

for(let ele of basicArray)
{
    console.log("----------------------------Basic Phone-----------------------------");
    console.log(ele.mobileId);
    console.log(ele.mobileName);
    console.log(ele.mobileType);
    console.log(ele.mobileCost);
} 

console.log("-------------------------------/////--------------------------------------");
console.log("-------------------------------/////--------------------------------------");
    
for(let ele of smartArray)
{
    console.log("----------------------------Smart Phone-----------------------------");
    console.log(ele.mobileId);
    console.log(ele.mobileName);
    console.log(ele.mobileType);
    console.log(ele.mobileCost);
} 