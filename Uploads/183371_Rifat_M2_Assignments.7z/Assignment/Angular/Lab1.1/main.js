"use strict";
exports.__esModule = true;
//let bPhone= new BasicPhone();
//let sPhone= new SmartPhone();
var basicArray = [
    { mobileId: 101, mobileName: "Nokia", mobileCost: 2000, mobileType: "BasicPhone" },
    { mobileId: 102, mobileName: "HTC", mobileCost: 2500, mobileType: "BasicPhone" }
];
var smartArray = [
    { mobileId: 1001, mobileName: "MI", mobileCost: 20000, mobileType: "SmartPhone" },
    { mobileId: 1002, mobileName: "Apple", mobileCost: 25000, mobileType: "SmartPhone" }
];
for (var _i = 0, basicArray_1 = basicArray; _i < basicArray_1.length; _i++) {
    var ele = basicArray_1[_i];
    console.log("----------------------------Basic Phone-----------------------------");
    console.log(ele.mobileId);
    console.log(ele.mobileName);
    console.log(ele.mobileType);
    console.log(ele.mobileCost);
}
console.log("-------------------------------/////--------------------------------------");
console.log("-------------------------------/////--------------------------------------");
for (var _a = 0, smartArray_1 = smartArray; _a < smartArray_1.length; _a++) {
    var ele = smartArray_1[_a];
    console.log("----------------------------Smart Phone-----------------------------");
    console.log(ele.mobileId);
    console.log(ele.mobileName);
    console.log(ele.mobileType);
    console.log(ele.mobileCost);
}
