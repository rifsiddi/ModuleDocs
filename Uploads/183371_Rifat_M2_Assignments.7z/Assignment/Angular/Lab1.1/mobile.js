"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile() {
    }
    return Mobile;
}());
exports.Mobile = Mobile;
