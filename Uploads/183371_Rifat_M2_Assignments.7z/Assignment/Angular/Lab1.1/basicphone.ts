import { Mobile } from "./mobile";

export class BasicPhone extends Mobile
{
    mobileType="BasicPhone"
}