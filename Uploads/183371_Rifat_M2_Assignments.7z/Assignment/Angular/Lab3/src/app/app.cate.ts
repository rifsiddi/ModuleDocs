export class Cate
{
    catId:number;
    catName:string;
}