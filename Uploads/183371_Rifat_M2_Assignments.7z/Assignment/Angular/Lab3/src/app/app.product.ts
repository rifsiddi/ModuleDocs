export class Product
{
    pId:number;
    pName:string;
    pCost:number;
    pOnline:string;
    pCategory:string;
    pStore:string[];
}