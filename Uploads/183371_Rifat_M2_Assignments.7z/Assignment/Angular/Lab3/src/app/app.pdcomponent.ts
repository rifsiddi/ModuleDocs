import {Component} from '@angular/core';
import {NgForm} from '@angular/Forms/forms';
import {FormsModule} from '@angular/Forms';
import {Product} from './app.product';
import {Cate} from './app.cate';

@Component(
    {
        selector:"pd-app",
        templateUrl:"./app.pdcomponent.html"
    }
)

export class PdComponent
{
    pd :Product={pId:null,pName:null,pCost:null,
        pOnline:null,pCategory:null,pStore:[]};
productId:number;
cat:Cate[]=
[
    {catId:10,catName:"Grocery"},
    {catId:20,catName:"Mobile"},
    {catId:30,catName:"Electronics"},
    {catId:40,catName:"Cloths"}

];
check:boolean=false;
storeList = ["Big Bazar ","DMart ","Reliance ","Mega Store "];
        
        getPdData(productForm:NgForm):void
        {
            console.log(productForm.value);
            this.productId=productForm.controls["txtpIdN"].value;
            console.log(this.pd.pId);
        }

        dispStore(data:any,index:any,isSelected:any):void
        {
            this.check=true;
            console.log(" : "+data +" : "+index+" : "+isSelected);
            if(isSelected==true)
            {
                this.pd.pStore.push(data);
            }
            else
            {
                var indx = this.pd.pStore.indexOf(data);
                this.pd.pStore.splice(indx,1);
            }
        }

}