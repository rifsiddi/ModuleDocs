import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';
import { Employee } from './app.employee';
import {FormsModule} from '@angular/Forms';


@Component(
    {
        selector:"emp-app",
        templateUrl:"./emp.component.html"
    }
)
export class EmpComponent extends Employee
{
    successText:string;
    index:number;

    emp :Employee={eId:null,eName:null,eSalary:null,
        eDepartment:null};

    uemp :Employee={eId:null,eName:null,eSalary:null,
            eDepartment:null};    

        employees:Employee[]=
        [
            {eId:1001,eName:"Rahul",eSalary:9000,eDepartment:"Java"},
            {eId:1002,eName:"Sachin",eSalary:19000,eDepartment:"OraApps"},
            {eId:1003,eName:"Vikash",eSalary:29000,eDepartment:"BI"}
        ];

        add()
        {
            this.employees.push({eId:this.emp.eId,eName:this.emp.eName,
                eSalary:this.emp.eSalary,eDepartment:this.emp.eDepartment})
                this.successText="Data Added";
                
        }

        
        updateEmp(i:number):void
        {
            this.uemp.eId=this.employees[i].eId;
            this.uemp.eName=this.employees[i].eName;
            this.uemp.eSalary=this.employees[i].eSalary;
            this.uemp.eDepartment=this.employees[i].eDepartment;
            this.index=i;
        }

        updateEmpDetails(empForm:NgForm):void
        {
            this.employees[this.index]=this.uemp;
            this.successText="Data Updated "+this.uemp.eId+" "+this.uemp.eName+" "
            +this.uemp.eSalary+" "+this.uemp.eDepartment;
            this.uemp={eId:null,eName:null,eSalary:null,
                eDepartment:null};
                this.index=null;
        }

        
        delete(index:number):void
        {
            this.employees.splice(index,1);
            this.successText="Data deleted"
            this.index=null;
        }

   
}