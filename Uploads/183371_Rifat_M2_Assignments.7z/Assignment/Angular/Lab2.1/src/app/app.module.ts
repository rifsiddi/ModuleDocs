﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { EmpComponent } from './emp.component';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [
        BrowserModule,FormsModule
        
    ],
    declarations: [
        AppComponent,EmpComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }