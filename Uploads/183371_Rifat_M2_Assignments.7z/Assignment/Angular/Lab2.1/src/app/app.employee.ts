export class Employee
{
    eId:number;
    eName:string;
    eSalary:number;
    eDepartment:string;
   
}