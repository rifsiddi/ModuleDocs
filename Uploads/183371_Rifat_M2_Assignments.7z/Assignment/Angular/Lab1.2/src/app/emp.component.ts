import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';
import { Employee } from './app.employee';
import {FormsModule} from '@angular/Forms';
import { EIDRM } from 'constants';

@Component(
    {
        selector:"emp-app",
        templateUrl:"./emp.component.html"
    }
)
export class EmpComponent
{
    emp :Employee={eId:null,eName:null,eSalary:null,
        eDepartment:null};

        display()
        {
            alert(this.emp.eId+" "+ this.emp.eName+" "+this.emp.eSalary+" "+this.emp.eDepartment)
        }


   
}