import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';
import { Employee } from './app.employee';

@Component(
    {
        selector:"emp-app",
        templateUrl:"./emp.component.html"
    }
)
export class EmpComponent extends Employee
{

    employees:Employee[]=
    [
    {eId:1001,eName:'Rahul',eSalary:9000,eDepartment:'JAVA',empjoiningdate:'6/12/2014'},
    {eId:1002,eName:'Vikash',eSalary:11000,eDepartment:'ORAAPS',empjoiningdate:'6/12/2017'},
    {eId:1003,eName:'Uma',eSalary:12000,eDepartment:'JAVA',empjoiningdate:'6/12/2010'},
    {eId:1004,eName:'Sachin',eSalary:11500,eDepartment:'ORAAPS',empjoiningdate:'11/12/2017'},
    {eId:1005,eName:'Amol',eSalary:7000,eDepartment:'.NET',empjoiningdate:'1/1/2018'},
    {eId:1006,eName:'Vishal',eSalary:17000,eDepartment:'BI',empjoiningdate:'9/12/2012'},
    {eId:1007,eName:'Rajita',eSalary:21000,eDepartment:'BI',empjoiningdate:'6/7/2014'},
    {eId:1008,eName:'Neelima',eSalary:81000,eDepartment:'TESTING',empjoiningdate:'6/17/2015'},
    {eId:1009,eName:'Daya',eSalary:1000,eDepartment:'TESTING',empjoiningdate:'6/17/2016'} 
];

sortId():any
{
    this.employees.sort(function(e1:any,e2:any)
    {
        var id1=e1.eId;
        var id2=e2.eId;
        if (id1<id2)
        return -1;
        if (id1>id2)
        return 1;
        return 0;
    }
    );
}

sortName():any
{
    this.employees.sort(function(e1:any,e2:any)
    {
        var name1=e1.eName.toUpperCase();
        var name2=e2.eName.toUpperCase();
        if (name1<name2)
        return -1;
        if (name1>name2)
        return 1;
        return 0;
    }
    );
}

sortSal():any
{
    this.employees.sort(function(e1:any,e2:any)
    {
        var sal1=e1.eSalary;
        var sal2=e2.eSalary;
        if (sal1<sal2)
        return -1;
        if (sal1>sal2)
        return 1;
        return 0;
    }
    );
}

sortDept():any
{
    this.employees.sort(function(e1:any,e2:any)
    {
        var dept1=e1.eDepartment.toUpperCase();
        var dept2=e2.eDepartment.toUpperCase();
        if (dept1<dept2)
        return -1;
        if (dept1>dept2)
        return 1;
        return 0;
    }
    );
}


}