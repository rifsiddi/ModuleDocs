import {Injectable} from '@angular/core';
import {IBook} from './app.book';
import {Book} from './app.book';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Http,Response,Headers, RequestOptions} from '@angular/http';

@Injectable()
export class BookService
{
    constructor(private http:HttpClient)
    {
    }
    getAllBook():any
    {
        return this.http.get('assets/booklist.json');
    }
}