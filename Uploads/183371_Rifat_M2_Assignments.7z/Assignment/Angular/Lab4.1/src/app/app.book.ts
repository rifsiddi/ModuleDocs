export interface IBook
{
    id:number,
    title:string,
    year:string,
    author:string
}
export class Book
{
    bId:number;
    bTitle:string;
}