﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpModule} from '@angular/http';
import {Routes, RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BookComponent } from './book.component';
import { SearchPipe } from './app.searchpipe';

@NgModule({
    imports: [
        BrowserModule, FormsModule, HttpModule,
        HttpClientModule
        
    ],
    declarations: [
        AppComponent,BookComponent,SearchPipe
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }