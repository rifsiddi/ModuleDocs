import {Pipe,PipeTransform} from '@angular/core';
import { IBook } from './app.book';
@Pipe(
    {
        name:"searchPipe"
    }
)
export class SearchPipe implements PipeTransform{
    transform(book:IBook[],id:any,title:string,author:string,year:string) {
        if(book)
        {
            return book.filter(book =>{
                if(id && book.id.toString().indexOf(id.toLowerCase())===-1)
                  {  return false;}

                if(title && book.title.toLowerCase().indexOf(title.toLowerCase()))
                 {   return false;}

                
                if(author && book.author.toLowerCase().indexOf(author.toLowerCase()))
                 {   return false;}
                
                if(year && book.year.toString().indexOf(year) === -1)
                   { return false;}
                   
                return true;

            })
        }
        else{
            return book;
        
    }
}

}