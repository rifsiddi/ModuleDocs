import {Component,OnInit} from '@angular/core';
import {NgForm} from '@angular/Forms/forms';
import {IBook} from './app.book';
import {Book} from './app.book';
import {BookService} from './app.bookservice';

@Component({
    selector:'book-app',
    templateUrl :'./book.component.html',
    providers:[BookService]
})

export class BookComponent implements OnInit
{
   
    books:IBook[];
    ngOnInit():void
    {
        this.bookService.getAllBook().subscribe((bookData)=>
        this.books=bookData);
    }
    constructor(private bookService:BookService)
    {
    }
}